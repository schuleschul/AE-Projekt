package backend;

public class AntwortValidierer
{
    public AntwortValidierer() {}

    public boolean istRichtig(Frage frage, String gegebeneAntwort)
    {
        return frage.getRichtigeAntwort().equals(gegebeneAntwort);
    }
}
